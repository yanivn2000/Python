a = True
b = True
c = False
d = False

print(a and b) #True
print(a and c) #False
print(c and d) #False
print()
print(a or b) #True
print(a or c) #True
print(c or d) #False
print()
print(not a) #False
print(not c) #True
