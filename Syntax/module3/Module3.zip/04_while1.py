count=-0
while count < 10:
    print(f"The count is:{count}")
    count+=1