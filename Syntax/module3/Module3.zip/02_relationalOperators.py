a = 4
b = 4
c = 5

print(a == b)#True
print(a == c)#False
print()
print(a != b)#False
print(a != c)#True
print()
print(a < b)#False
print(a < c)#True
print()
print(a <= b)#True
print(a <= c)#True
print()
print(a >= b)#True
print(a >= c)#False