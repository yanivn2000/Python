#slide 8
import re

txt = '11a22b33c'

# search a specific
m = re.search(r'\d+', txt)
print(f"{m.group()} {m.start()} {m.end()}") # ['a', 'b', 'c', '']

print()
#get group of items
res = re.finditer(r'\d+', txt)
for m in res:
    print(f"{m.group()} {m.start()} {m.end()}")  # ['a', 'b', 'c', '']
