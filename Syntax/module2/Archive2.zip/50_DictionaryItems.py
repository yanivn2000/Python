#get list of tuples

dic={'k1':'v1', 'k2':'v2', 'k3':'v3'}
list=dic.items()

print(list)