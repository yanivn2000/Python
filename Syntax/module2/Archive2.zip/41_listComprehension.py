list1 = ['ab', 'cd', 'ef']
list2 = [char for string in list1 for char in string]

print(list2)


list3 = []
for string in list2:
    for char in string:
        list3.append((char))

print(list3)