#return the count of searched element in the list
list=["a","b","c", "a"]
c=list.count("a")
print(c) #2