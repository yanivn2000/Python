#numbers placeholders
a=1
b="Yaniv"
s1="a is {0}, b is {1}".format(a,b)
print(s1)

#named placeholders
s1="a is {a}, b is {b}".format(a=10,b="Joy")
print(s1)

#Width and aligmnet can be specified
print("{0:<20}.".format(("A")))
print("{0:^20}.".format(("A")))
print("{0:>20}.".format(("A")))

#Floating point
res=10.0/3
print("{:.2f}".format(res))