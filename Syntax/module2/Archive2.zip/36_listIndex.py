#return the index of element
list=["a","b","c"]
e=list.index("b")
print(e) #1