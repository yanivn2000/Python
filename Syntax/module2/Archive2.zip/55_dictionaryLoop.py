dict={'k1':'v1', 'k2':'v2', 'k3':'v3'}

for i in dict:
    print(i)

for i in dict:
    print(dict[i])