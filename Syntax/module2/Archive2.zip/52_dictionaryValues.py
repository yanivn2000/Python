#get list of keys

dic={'k1':'v1', 'k2':'v2', 'k3':'v3'}
list=dic.values()

print(list)