list=['a','e','d','c','b']
list.sort()
print(list)

list.sort(reverse=True)
print(list)

list=['abn','ennop','dddddd','c1','b']
list.sort(key=len)
print(list)
list=[5,1,2,3,4]
list2=sorted(list)#return a sorted list (do not change the original list)
print(list)
print(list2)


