#Wrong
#s1="a"+
#    "b"

#Correct
s2="a" +\
    "b"

#List OK
l=[1,
   2,3,
   4]

#OK
n1=9;n2=11;n3=90
