#another way of import - select specific functionality
from math import factorial
#from math import factorial as fact # - in case there is colision between 2 functions with the same name

print(factorial(5))
#print(fact(5))
