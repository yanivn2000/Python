#clear
s = {1,2,3}
s.clear()
print(s)