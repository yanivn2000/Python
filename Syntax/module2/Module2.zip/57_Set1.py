d1 = {} #creates dictionary
print(type(d1))

d2 = dict()
print(type(d2))

s = set()
print(type(s))
