#https://docs.python.org/3/reference/datamodel.html
print(__name__)#current module (now we have only one module) - will be explained later

print("end")