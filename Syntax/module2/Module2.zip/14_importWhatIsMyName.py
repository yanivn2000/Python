#will print the name of the module imported and not the name of the file that imports
#helps to know in which module are we
import whatIsMyName
print(__name__)