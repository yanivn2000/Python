#Built in functions (not methods!)

s="abc"
l=[1,2,3,5]
print(f"a len {len(s)}")
print(f"l len {len(l)}")