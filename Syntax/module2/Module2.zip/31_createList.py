#empty list
a = []

b = [1,2,3,4,5]

#multi list
c = [5,
     6,]

#create list uzing constructor
str="abc"
d = list("abc") #['a','b','c']

e="My name is Yaniv".split() #["My", "name", "is", "Yaniv"]

f="Another;split;example".split(";") #["Another", "split", "example"]


