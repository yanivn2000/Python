#Saved with \n
a="""
Arsenal
Chelsea
Liverpool
Manchester City
Manchester United
Tottenham Hotspur
Atletico Madrid
Barcelona
Real Madrid
Bayern Munich
Borussia Dortmund
Juventus
Paris Saint Germain
"""
print(a)

a = """This is a welcome message
To login\t To register"""
print(a)