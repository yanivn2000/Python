#differenceupdate
s={1,2,3}
s.difference_update([1,3,4])
print(s) #1