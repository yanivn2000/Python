#Built in functions (not methods!)

s="abc"
l=[1,2,3,5]
print(f"a len {max(s)}")
print(f"l len {max(l)}")