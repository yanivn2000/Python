a="how r u doing?"
b='These pretzels are making me thirsty'
c='Yada\nYada\nYada'
d="it's not a lie if you believe it"
#d='it\'s not a lie if you believe it'
e="c:\\Documents"
#e=r"x:\Documents"

print(a)
print(b)
print(c)
print(d)
print(e)

print("My name is %s and my age is %d" % ("Yaniv", 43))