#Complex numbers
#An complex number is represented by “ x + yi “.
# Python converts the real numbers x and y into complex using the function complex(x,y).
# The real part can be accessed using the function real() and imaginary part can be represented by imag()

#read about complex numbers: https://en.wikipedia.org/wiki/Complex_number

a=2+3j
b=a.real
c=a.imag
d=complex(2,3)


print(a,b,c,d)