#List to set
l = [4, 1,2,2,3]
s = set(l)
print(s) #1,2,3
