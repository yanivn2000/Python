s1="a"+"b"+"c"
s2='-'.join(["a","b","c"]) #better perforamnce than above

print(s1)
print(s2)