#update
s = {1,2,3}
s.update({2,3,4})#update with set
s.update([2,3,5])#update with list
print(s) #1,2,3,4