# ***** replacing function ****** #
str="abVca"
str=str.replace("a", "A")
print(f"replace a with A= {str}")


# ***** more functions ****** #
str=str.upper()
print(f"after upper: {str}")
str=str.lower()
print(f"after lower: {str}")



