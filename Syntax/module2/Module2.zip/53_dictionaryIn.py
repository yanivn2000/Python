#get list of keys

dict={'k1':'v1', 'k2':'v2', 'k3':'v3'}
print('k1' in dict)
print('kNOT' in dict)
