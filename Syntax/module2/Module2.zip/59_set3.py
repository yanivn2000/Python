#Shows that the set is not in order
for x in {1,2,4,8,16,32}:
    print(x)
