
l1 = [1,2,3]
l2 = l1#points to the same memory
l1.append(4)

#What will be the ouput?
print(l1,l2)