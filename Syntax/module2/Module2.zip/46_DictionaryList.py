#List of dictionary

list = [
    {'a':'a1', 'b':'b2'},
    {'a':1, 'b':2, 'c':3},
    {1:1, 2:22, 3:333}
]

print(list)

print(list[1]['a'])