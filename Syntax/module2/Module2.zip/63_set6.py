#add
s = {1,2,3}
s.add(4)
s.add(3)
print(s)