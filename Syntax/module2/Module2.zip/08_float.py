a=3.14 #3.14
b=3e8 #300000000.0
c=3e-2 #0.03
d=float(1) #1.0
e=float(3.2) #3.2
f=3.2+1 #4.2 float + int is float
g=10/3 #3.33333333335
h=10//3 #3
h=float(10//3) #3.0

print(f"{a}\n{b}\n{c}",d,e,f,g,h)