name=input("Please enter your name:")
print(f"Welcome {name}")