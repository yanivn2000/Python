#input nc
#n=number
#c=char
#output should be n times c
#for example the input is 3j the output will be jjj
#for example the input is 1h the output will be h
#for example the input is 9P the output will be PPPPPPPPP













value=input("insert nc e.g. 3G, 9P etc:")
print(int(value[0])*value[1])