# a=1 #1
# b=0b10 #binary - 2
# c=0o10 #Octat - 8
# d=0x10 #hex - 16
#
# e=int(3.2) #3
# f=int(3.8) #3
#
# g=int(-3.2) #3
# h=int(-3.8) #3
#
# i=round(3.2) #3
# j=round(3.5) #4
# k=round(3.8) #4
#
# l = int("1009")#1009
# print(a,b,c,d,e,f,g,h,i,j,k,l)

a1,b1,c1=4,6,9
print(a1,b1,c1)

a1,b1,c1="hello","World"
print(a1,b1,c1)

