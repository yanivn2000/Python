#return the count of searched element in the list
list=["akk","ba","c", "akk"]
c=list.count("akk")
print(c) #2